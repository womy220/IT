from django.shortcuts import render
from django.http import HttpResponse
from .models import Deliveries



def deliveries(request):
	t = Deliveries.objects.all()
	return render(request, "gasstation/showdeliveries.html", {'t' : t})

def refueling(request):
	return render(request, "gasstation/refueling.html")
