import time

i=0

def start1(i):
	i+=1
	time.sleep(1)
	return(start1(i))