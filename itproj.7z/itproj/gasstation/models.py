from django.db import models
from django.utils import timezone


class Deliveries(models.Model):
	ID = models.BigAutoField(primary_key=True)

	fuel_type_choices = [
		('Gasoline 95', 'Gasoline 95'),
		('Gasoline 98', 'Gasoline 98'),
		('Diesel', 'Diesel'),
		('Diesel Premium', 'Diesel Premium'),
		('Gas', 'Gas'),
	]
	fuel_type = models.CharField(max_length=20, choices=fuel_type_choices)
		
	quantity_in_liters = models.PositiveIntegerField()

	supplier_choices = [
		('Orlen', 'Orlen'),
		('Lotos', 'Lotos'),
		('BP', 'BP'),
		('Lukoil', 'Lukoil'),
		('Neste', 'Neste'),
		('Shell', 'Shell'),
		('Statoil', 'Statoil'),
	]
	supplier = models.CharField(max_length=20, choices=supplier_choices)
	date = models.DateTimeField(default=timezone.now)

	def save(self):
		fuel = Fuel.objects.get(fuel_type = self.fuel_type)
		fuel.quantity_in_liters += self.quantity_in_liters
		fuel.save()
		super().save()


class Fuel(models.Model):
	fuel_type_choices = [
		('Gasoline 95', 'Gasoline 95'),
		('Gasoline 98', 'Gasoline 98'),
		('Diesel', 'Diesel'),
		('Diesel Premium', 'Diesel Premium'),
		('Gas', 'Gas'),
	]
	fuel_type = models.CharField(max_length=20, choices=fuel_type_choices)
	quantity_in_liters = models.PositiveIntegerField()


