from django.shortcuts import render
from django.http import HttpResponse, FileResponse
from .models import Deliveries
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
import io
from .models import Fuel
import datetime
from time import gmtime, strftime

def deliveries(request):
	t = Deliveries.objects.all()
	return render(request, "gasstation/showdeliveries.html", {'t' : t})

def refueling(request):
	print(request.GET)
	refuel = request.GET.get("ref_pay")
	money = request.GET.get("mon_pay")
	nip = request.GET.get("nip_input")
	minusf1 = request.GET.get("f1_pay")
	minusf2 = request.GET.get("f2_pay")
	minusf3 = request.GET.get("f3_pay")
	minusf4 = request.GET.get("f4_pay")
	minusf5 = request.GET.get("f5_pay")
	if(minusf1 != None):
		minusf1 = int(minusf1)
		fuel1 = Fuel.objects.get(fuel_type = 'Gasoline 95')
		fuel1.quantity_in_liters = fuel1.quantity_in_liters - minusf1
		fuel1.save()
	if(minusf2 != None):
		minusf2 = int(minusf2)
		fuel2 = Fuel.objects.get(fuel_type = 'Gasoline 98')
		fuel2.quantity_in_liters = fuel2.quantity_in_liters - minusf2
		fuel2.save()
	if(minusf3 != None):
		minusf3 = int(minusf3)
		fuel3 = Fuel.objects.get(fuel_type = 'Diesel')
		fuel3.quantity_in_liters = fuel3.quantity_in_liters - minusf3
		fuel3.save()
	if(minusf4 != None):
		minusf4 = int(minusf4)
		fuel4 = Fuel.objects.get(fuel_type = 'Diesel Premium')
		fuel4.quantity_in_liters = fuel4.quantity_in_liters - minusf4
		fuel4.save()
	if(minusf5 != None):
		minusf5 = int(minusf5)
		fuel5 = Fuel.objects.get(fuel_type = 'Gas')
		fuel5.quantity_in_liters = fuel5.quantity_in_liters - minusf5
		fuel5.save()
	request.session['refuel'] = refuel
	request.session['money'] = money
	request.session['nip'] = nip
	return render(request, "gasstation/refueling.html")

def pay_pdf(request):
	time = strftime("%H:%M:%S", gmtime())
	date = datetime.date.today()
	refuel = request.session.get('refuel')
	money = request.session.get('money')
	money = float(money)
	tax = round(0.23 * money, 2)
	nip = request.session.get('nip')
	buf=io.BytesIO()
	p=canvas.Canvas(buf, pagesize=letter, bottomup=0)
	textob = p.beginText()
	textob.setTextOrigin(inch, inch)
	textob.setFont("Helvetica", 14)
	lines = [
		"                                              GAS STATION",
		"                                             21 RANDOM RD.",
		"                                             GLIWICE, 44-103",
		"---------------------------------------------------------------------------------------------------",
		"DATE                                                                                   {}".format(date),
		"TIME                                                                                    {}".format(time),
		"---------------------------------------------------------------------------------------------------",
		"                                                    DETAILS",
		"LITERS                                                                                  {}".format(refuel),
		"TOTAL                                                                                   {}".format(money),
		"INCLUDED TAX                                                                    {}".format(tax),
		"---------------------------------------------------------------------------------------------------",
		"                                             CUSTOMERS NIP",
		"                                                   {}".format(nip),
	]

	for line in lines:
		textob.textLine(line)
	p.drawText(textob)
	p.showPage()
	p.save()
	buf.seek(0)
	return FileResponse(buf, as_attachment=True, filename='invoice.pdf')

def home(request):
	return render(request, "gasstation/home.html")

def showfuel(request):
	f = Fuel.objects.all()
	return render(request, "gasstation/showfuel.html", {'f' : f})

def about(request):
	return render(request, "gasstation/about.html")