from django.urls import path

from . import views

urlpatterns = [
path('deliveries/', views.deliveries), 
path('refueling/', views.refueling),
path('', views.refueling),
path('home/', views.home),
path('pay_pdf', views.pay_pdf, name='pay_pdf'),
path('showfuel/', views.showfuel),
path('about/', views.about),
]