from django.contrib import admin
from .models import Deliveries
from .models import Fuel

admin.site.register(Deliveries)
admin.site.register(Fuel)