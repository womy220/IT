from django.urls import path

from . import views

urlpatterns = [
path('deliveries/', views.deliveries), 
path('refueling/', views.refueling),
path('pay/', views.pay),
path('home/', views.home),
path('pay_pdf', views.pay_pdf, name='pay_pdf'),
]