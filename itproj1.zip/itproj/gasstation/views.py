from django.shortcuts import render
from django.http import HttpResponse, FileResponse
from .models import Deliveries
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
import io

def deliveries(request):
	t = Deliveries.objects.all()
	return render(request, "gasstation/showdeliveries.html", {'t' : t})

def refueling(request):
	return render(request, "gasstation/refueling.html")

def pay_pdf(request):
	buf=io.BytesIO()
	p=canvas.Canvas(buf, pagesize=letter)
	p.drawString(100,100,"Fakturka dla kierownika")
	p.showPage()
	p.save()
	buf.seek(0)
	return FileResponse(buf, as_attachment=True, filename='fakturka.pdf')

def home(request):
	return render(request, "gasstation/home.html")
def pay(request):
	return request