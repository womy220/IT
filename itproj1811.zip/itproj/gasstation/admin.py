from django.contrib import admin
from .models import Deliveries

admin.site.register(Deliveries)
